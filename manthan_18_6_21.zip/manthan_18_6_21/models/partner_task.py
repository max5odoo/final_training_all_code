from odoo import api, fields, models


class Partner_task(models.Model):
    _inherit = 'res.partner'

    @api.model
    def name_get(self):
        partner_name_gets = []
        for rec in self:
            if rec.env.context.get('custom_search'):
                partner_id = f"{rec.name}/{rec.city} "
                partner_name_gets.append((rec.id, partner_id))
        return partner_name_gets

    def _name_search(self, name='', args=None, operator='ilike', limit=100):
        args = args or []
        domain = []
        if name:
            domain = ['|', '|', ('name', operator, name), ('city', operator, name)]
        return self._search(domain + args, limit=limit)

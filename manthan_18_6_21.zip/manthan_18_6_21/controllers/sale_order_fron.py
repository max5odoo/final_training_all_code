from odoo import http, _
from odoo.http import request, route
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager


class Registration_sale_route(http.Controller):
    @http.route('/register/sale/prac', type='http', auth='public', website=True)
    def sale_registration(self):
        return http.request.render('manthan_18_6_21.sale_order_front')

    @http.route('/sale_front/form/submit', type='http', auth='public', website=True)
    def sale_post_data(self, page=1, sortby=None,
                       groupby=None, **post):
        print(f"\n\n\n\nthis is post--->{post}\n\n\n")
        values = {}
        searchbar_sortings = {
            'name': {'label': _('name'), 'order': 'start_date '},
        }

        searchbar_groupby = {
            'none': {'input': 'none', 'label': _('None')},
            'gender': {'input': 'start_date', 'label': _('start date')},

        }

        # default group by value
        if not groupby:
            groupby = 'start_date'
        # pager
        pager = portal_pager(
            url="/home",
            url_args={'sortby': sortby, 'groupby': groupby},
            page=page,
            step=3
        )
        sale_details = request.env['sale.order'].sudo().search(
            [('login_user', '=', request.env.user.id), ('date_order', '>', 'start_date'),
             ('date_order', '<', 'end_date')], limit=3, offset=pager['offset'])
        vals = {
            'pager': pager,
            'sortby': sortby,
            'groupby': groupby,
            'sale_details': sale_details,
            'searchbar_sortings': searchbar_sortings,
            'searchbar_groupby': searchbar_groupby,

        }
        return request.render("manthan_18_6_21.sale_order_detail_page", vals)
